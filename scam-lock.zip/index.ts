// Entrypoint for TypeScript hosting environments (e.g. ts-node index.ts)
import './index.js';
