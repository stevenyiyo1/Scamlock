import { createRequire } from 'node:module';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawn } from 'node:child_process';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const require = createRequire(import.meta.url);

const distServer = path.join(__dirname, 'dist', 'server.cjs');

if (fs.existsSync(distServer)) {
  console.log('[Scam Lock] 🚀 Iniciando Scam Lock desde dist/server.cjs...');
  require('./dist/server.cjs');
} else {
  console.log('[Scam Lock] No se encontró dist/server.cjs compilado.');
  console.log('[Scam Lock] Iniciando automáticamente mediante tsx server.ts...');
  const child = spawn('npx', ['tsx', 'server.ts'], {
    stdio: 'inherit',
    shell: true,
    env: process.env,
  });

  child.on('exit', (code) => {
    process.exit(code || 0);
  });
}
