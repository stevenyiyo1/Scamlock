# Guía de Publicación en GitHub Pages — Scam Lock

Esta web oficial de **Scam Lock** está optimizada para ser publicada de forma 100% estática en **GitHub Pages**.

---

## Opción 1: Despliegue Automático con GitHub Actions (Recomendada)

El repositorio ya incluye el archivo de flujo de trabajo `.github/workflows/deploy.yml`. Para activarlo:

1. Sube este proyecto a tu repositorio de GitHub (rama `main`).
2. En GitHub, ve a la pestaña **Settings** > **Pages**.
3. En la sección **Build and deployment**:
   - **Source**: Selecciona **GitHub Actions**.
4. ¡Listo! Cada vez que hagas un `git push` a `main`, GitHub compilará el proyecto automáticamente y lo publicará en tu URL (por ejemplo `https://tu-usuario.github.io/scamlock-bot/` o tu dominio personalizado).

---

## Opción 2: Despliegue Manual con la rama `gh-pages`

Si prefieres compilar localmente y subir la carpeta `dist`:

1. Instala las dependencias y compila:
   ```bash
   npm install
   npm run build
   ```
2. La carpeta `dist` contendrá todo el sitio web estático listo para servir, incluyendo el archivo `404.html` para el soporte de rutas como `/privacy`, `/terms`, `/support`, `/security`.
3. Puedes usar la herramienta estándar `gh-pages`:
   ```bash
   npx gh-pages -d dist
   ```

---

## Personalización de Datos Antes de Publicar

Antes de publicar en producción, edita el archivo:
📁 **`/src/data/branding.ts`**

Rellena los siguientes campos con tus datos reales:
- `ownerName`: Tu nombre o titular legal.
- `ownerAlias`: Tu alias o usuario de Discord/GitHub.
- `contactEmail`: Tu correo electrónico de contacto.
- `supportEmail`: Tu correo electrónico de soporte.
- `securityEmail`: Tu correo para reporte de vulnerabilidades.
- `discordInviteUrl`: Enlace de invitación oficial de tu bot con tu `client_id`.
- `discordSupportServerUrl`: Enlace de invitación a tu servidor de soporte en Discord.
- `githubRepoUrl`: Enlace a tu repositorio público.
