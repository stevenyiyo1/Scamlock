// Scam Lock - Universal Main Entrypoint
import './index.js';
