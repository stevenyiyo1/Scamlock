export type RiskLevel = 'low' | 'suspicious' | 'high' | 'critical';

export type RiskCategory =
  | 'keyword'
  | 'url'
  | 'urgency'
  | 'typosquat'
  | 'tld'
  | 'spoofing'
  | 'crypto'
  | 'nitro'
  | 'social_engineering'
  | 'easy_money'
  | 'suspicious_prize'
  | 'indirect_redirect'
  | 'impersonation'
  | 'sensitive_info'
  | 'synergy'
  | 'financial_scam'
  | 'get_rich_quick'
  | 'fake_investment'
  | 'recruitment_scam'
  | 'advance_fee'
  | 'unrealistic_profit';

export interface RiskFactor {
  category: RiskCategory;
  points: number;
  description: string;
  evidence?: string;
}

export type SocialEngineeringSignalType =
  | 'easy_money'
  | 'suspicious_prize'
  | 'artificial_urgency'
  | 'indirect_redirect'
  | 'impersonation'
  | 'sensitive_info';

export interface SocialEngineeringSignal {
  type: SocialEngineeringSignalType;
  name: string;
  points: number;
  evidence?: string;
  description: string;
}

export interface SocialEngineeringReport {
  detectedSignals: SocialEngineeringSignal[];
  distinctSignalsCount: number;
  synergyBonus: number;
  isMultiSignalScam: boolean;
  correlationLevel: 'none' | 'single_signal' | 'suspicious_combo' | 'high_risk_combo' | 'critical_takeover';
}

export type FinancialScamSignalType =
  | 'unrealistic_profit'
  | 'limited_time_urgency'
  | 'recruitment_funnel'
  | 'profit_percentage_fee'
  | 'vague_high_return_scheme'
  | 'pyramid_ponzi_referral';

export interface FinancialScamSignal {
  type: FinancialScamSignalType;
  category: RiskCategory;
  name: string;
  points: number;
  evidence?: string;
  description: string;
}

export interface FinancialScamReport {
  isFinancialScam: boolean;
  signalsCount: number;
  signals: FinancialScamSignal[];
  hasEducationalContext: boolean;
  educationalEvidence?: string;
  synergyBonus: number;
  confidenceScore: number;
}

export interface AnalysisResult {
  score: number; // 0 to 100
  level: RiskLevel;
  levelLabel: string;
  factors: RiskFactor[];
  detectedUrls: string[];
  isWhitelisted: boolean;
  actionTaken: 'none' | 'logged' | 'alerted' | 'deleted_and_alerted';
  analysisTimeMs: number;
  socialEngineering?: SocialEngineeringReport;
  financialScam?: FinancialScamReport;
}

export type SanctionType = 'timeout' | 'ban';

export type SanctionActionExecuted =
  | 'ban'
  | 'timeout'
  | 'alert_only'
  | 'blocked_protected_user'
  | 'blocked_protected_role'
  | 'blocked_hierarchy'
  | 'blocked_is_owner'
  | 'blocked_is_bot'
  | 'failed_permissions'
  | 'rate_limited_dedup';

export interface SanctionRecord {
  id: string;
  timestamp: string;
  guildId: string;
  guildName: string;
  userId: string;
  userTag: string;
  userAvatar?: string;
  score: number;
  level: RiskLevel;
  reasons: string[];
  factors: RiskFactor[];
  messageContent: string;
  detectedUrls: string[];
  actionExecuted: SanctionActionExecuted;
  sanctionType: SanctionType | 'none';
  durationMinutes?: number;
  executor: 'AUTOMATIC_POLICY' | string;
  manualReviewRequired: boolean;
  status: 'applied' | 'alert_sent' | 'blocked' | 'reviewed';
  reviewed: boolean;
  reviewedBy?: string;
  reviewedAt?: string;
  reviewNotes?: string;
}

export interface ServerConfig {
  guildId: string;
  guildName: string;
  enabled: boolean;
  logChannelId: string;
  logChannelName: string;
  alertChannelId: string;
  alertChannelName: string;
  alertThreshold: number; // default 61 (Alto riesgo)
  deleteThreshold: number; // default 81 (Crítico)
  whitelist: string[];
  // Automatic sanction system (Default: false)
  autoSanctionEnabled: boolean;
  sanctionThreshold: number; // min 75, default 90
  sanctionType: SanctionType; // 'timeout' | 'ban'
  timeoutDurationMinutes: number; // default 60
  protectedUsers: string[];
  protectedRoles: string[];
}

export interface SecurityLog {
  id: string;
  timestamp: string;
  guildId: string;
  guildName: string;
  userId: string;
  userTag: string;
  userAvatar?: string;
  channelId: string;
  channelName: string;
  messageContent: string;
  detectedUrls: string[];
  score: number;
  level: RiskLevel;
  reasons: string[];
  actionTaken: 'none' | 'logged' | 'alerted' | 'deleted_and_alerted';
  messageDeleted: boolean;
}

export interface BotStatus {
  online: boolean;
  botTag: string | null;
  botId: string | null;
  guildsCount: number;
  analyzedCount: number;
  scamsBlocked: number;
  uptimeSeconds: number;
  pingMs: number;
  mode: 'connected' | 'standby' | 'simulated';
}
