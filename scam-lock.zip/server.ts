import dotenv from 'dotenv';
import express from 'express';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import { analyzeMessage } from './src/bot/analyzer/riskEngine';
import { getBotStatus, initDiscordBot } from './src/bot/botClient';
import { guildConfigManager } from './src/bot/config/guildConfig';
import { deploySlashCommands } from './src/bot/deploy-commands';
import { logService } from './src/bot/services/logService';
import { sanctionPolicyManager } from './src/bot/services/sanctionPolicyManager';

dotenv.config();

// Support both ESM (tsx) and CJS (compiled esbuild bundle)
const getDirname = () => {
  if (typeof __dirname !== 'undefined') return __dirname;
  return path.dirname(fileURLToPath(import.meta.url));
};

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // ================= API ENDPOINTS =================

  // 1. Bot & System Status
  app.get('/api/status', (req, res) => {
    try {
      const status = getBotStatus();
      res.json(status);
    } catch (err) {
      res.status(500).json({ error: (err as Error).message });
    }
  });

  // Download project ZIP
  app.get('/api/download-zip', (req, res) => {
    try {
      const zipPath = path.join(process.cwd(), 'public', 'scamlock-bot.zip');
      if (fs.existsSync(zipPath)) {
        res.setHeader('Content-Type', 'application/zip');
        res.setHeader('Content-Disposition', 'attachment; filename="scamlock-bot.zip"');
        res.download(zipPath, 'scamlock-bot.zip');
      } else {
        res.status(404).json({ error: 'ZIP aún no generado' });
      }
    } catch (err) {
      res.status(500).json({ error: (err as Error).message });
    }
  });

  // 2. Real-time Analysis (Live Test Engine)
  app.post('/api/analyze', (req, res) => {
    try {
      const { content, guildId = 'default', saveLog = false, authorTag = 'Usuario#1234' } = req.body;

      if (typeof content !== 'string') {
        res.status(400).json({ error: 'El campo "content" es requerido.' });
        return;
      }

      const config = guildConfigManager.getConfig(guildId);
      const analysis = analyzeMessage(content, config);

      if (saveLog && analysis.score >= 31) {
        logService.recordLog(
          { id: config.guildId, name: config.guildName },
          { id: 'sim-user-' + Math.floor(Math.random() * 9000 + 1000), tag: authorTag },
          { id: 'chat-general', name: '#chat-general' },
          content,
          analysis,
          analysis.actionTaken === 'deleted_and_alerted'
        );
      }

      res.json({
        analysis,
        config: {
          alertThreshold: config.alertThreshold,
          deleteThreshold: config.deleteThreshold,
          enabled: config.enabled,
        },
      });
    } catch (err) {
      res.status(500).json({ error: (err as Error).message });
    }
  });

  // 3. Security Incident Logs
  app.get('/api/logs', (req, res) => {
    try {
      const guildId = req.query.guildId as string;
      const level = req.query.level as string;
      const limit = req.query.limit ? parseInt(req.query.limit as string, 10) : 50;

      const logs = logService.getLogs({ guildId, level, limit });
      res.json(logs);
    } catch (err) {
      res.status(500).json({ error: (err as Error).message });
    }
  });

  // 4. Server Configurations
  app.get('/api/config', (req, res) => {
    try {
      const guildId = (req.query.guildId as string) || 'default';
      const config = guildConfigManager.getConfig(guildId);
      res.json(config);
    } catch (err) {
      res.status(500).json({ error: (err as Error).message });
    }
  });

  app.post('/api/config', (req, res) => {
    try {
      const {
        guildId = 'default',
        enabled,
        alertThreshold,
        deleteThreshold,
        alertChannelName,
        logChannelName,
        autoSanctionEnabled,
        sanctionType,
        sanctionThreshold,
        timeoutDurationMinutes,
        protectedUsers,
        protectedRoles,
      } = req.body;

      const updates: Record<string, unknown> = {};
      if (typeof enabled === 'boolean') updates.enabled = enabled;
      if (typeof alertThreshold === 'number') updates.alertThreshold = alertThreshold;
      if (typeof deleteThreshold === 'number') updates.deleteThreshold = deleteThreshold;
      if (typeof alertChannelName === 'string') updates.alertChannelName = alertChannelName;
      if (typeof logChannelName === 'string') updates.logChannelName = logChannelName;
      if (typeof autoSanctionEnabled === 'boolean') updates.autoSanctionEnabled = autoSanctionEnabled;
      if (sanctionType === 'timeout' || sanctionType === 'ban') updates.sanctionType = sanctionType;
      if (typeof sanctionThreshold === 'number') updates.sanctionThreshold = sanctionThreshold;
      if (typeof timeoutDurationMinutes === 'number') updates.timeoutDurationMinutes = timeoutDurationMinutes;
      if (Array.isArray(protectedUsers)) updates.protectedUsers = protectedUsers;
      if (Array.isArray(protectedRoles)) updates.protectedRoles = protectedRoles;

      const updated = guildConfigManager.updateConfig(guildId, updates);
      res.json(updated);
    } catch (err) {
      res.status(500).json({ error: (err as Error).message });
    }
  });

  // 5. Protected Users & Roles Management
  app.post('/api/protected', (req, res) => {
    try {
      const { guildId = 'default', type, action, id } = req.body;
      if (!id || typeof id !== 'string') {
        res.status(400).json({ error: 'Debes proporcionar un ID de Discord válido.' });
        return;
      }

      if (type === 'user') {
        if (action === 'remove') {
          guildConfigManager.removeProtectedUser(guildId, id);
        } else {
          guildConfigManager.addProtectedUser(guildId, id);
        }
      } else if (type === 'role') {
        if (action === 'remove') {
          guildConfigManager.removeProtectedRole(guildId, id);
        } else {
          guildConfigManager.addProtectedRole(guildId, id);
        }
      } else {
        res.status(400).json({ error: 'Tipo no válido ("user" o "role").' });
        return;
      }

      const config = guildConfigManager.getConfig(guildId);
      res.json({
        success: true,
        protectedUsers: config.protectedUsers,
        protectedRoles: config.protectedRoles,
      });
    } catch (err) {
      res.status(500).json({ error: (err as Error).message });
    }
  });

  // 6. Sanctions & Incident Review Management
  app.get('/api/sanctions', (req, res) => {
    try {
      const { guildId, userId, limit } = req.query;
      const records = sanctionPolicyManager.getSanctions({
        guildId: typeof guildId === 'string' ? guildId : undefined,
        userId: typeof userId === 'string' ? userId : undefined,
        limit: typeof limit === 'string' ? parseInt(limit, 10) : 50,
      });
      res.json(records);
    } catch (err) {
      res.status(500).json({ error: (err as Error).message });
    }
  });

  app.get('/api/sanctions/:id', (req, res) => {
    try {
      const record = sanctionPolicyManager.getSanctionById(req.params.id);
      if (!record) {
        res.status(404).json({ error: 'Expediente de sanción no encontrado.' });
        return;
      }
      res.json(record);
    } catch (err) {
      res.status(500).json({ error: (err as Error).message });
    }
  });

  app.post('/api/sanctions/review', (req, res) => {
    try {
      const { id, reviewer = 'Admin Web', notes = '' } = req.body;
      if (!id || typeof id !== 'string') {
        res.status(400).json({ error: 'ID de incidente requerido.' });
        return;
      }
      const updated = sanctionPolicyManager.reviewIncident(id, reviewer, notes);
      if (!updated) {
        res.status(404).json({ error: 'Incidente no encontrado.' });
        return;
      }
      res.json({ success: true, record: updated });
    } catch (err) {
      res.status(500).json({ error: (err as Error).message });
    }
  });

  // 5. Whitelist Management
  app.post('/api/whitelist', (req, res) => {
    try {
      const { guildId = 'default', action, domain } = req.body;

      if (!domain || typeof domain !== 'string') {
        res.status(400).json({ error: 'Debes proporcionar un dominio válido.' });
        return;
      }

      let updatedList: string[];
      if (action === 'remove') {
        updatedList = guildConfigManager.removeWhitelistDomain(guildId, domain);
      } else {
        updatedList = guildConfigManager.addWhitelistDomain(guildId, domain);
      }

      res.json({ success: true, whitelist: updatedList });
    } catch (err) {
      res.status(500).json({ error: (err as Error).message });
    }
  });

  // 6. Deploy Discord Slash Commands
  app.post('/api/deploy-commands', async (req, res) => {
    try {
      const { token, clientId, guildId } = req.body;
      const result = await deploySlashCommands(token, clientId, guildId);
      res.json(result);
    } catch (err) {
      res.status(500).json({ success: false, message: (err as Error).message });
    }
  });

  // ================= VITE OR STATIC SERVING =================
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  // Attempt Discord bot login in background if token exists
  initDiscordBot().catch((err) => {
    console.log('[Scam Lock] Discord Bot inicializado en modo simulación.');
  });

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[Scam Lock] 🌐 Servidor web y API ejecutándose en http://0.0.0.0:${PORT}`);
  });
}

startServer();
