// Scam Lock - Universal Server Entrypoint
import './index.js';
