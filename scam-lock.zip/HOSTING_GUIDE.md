# 🛡️ Scam Lock — Guía de Despliegue y Hosting

Esta guía te explica cómo poner en marcha Scam Lock 24/7 en cualquier hosting o VPS.

---

## 1. Requisitos Previos

- **Node.js**: Versión 18 o superior (recomendado Node 20 LTS).
- **npm** o **bun** o **yarn**.
- **Credenciales de Discord**:
  - `DISCORD_TOKEN`: Token del bot (obtenido en Discord Developer Portal > Bot > Reset Token).
  - `DISCORD_CLIENT_ID`: ID de aplicación (General Information > Application ID).
  - `DISCORD_GUILD_ID` *(Opcional)*: ID de tu servidor de pruebas para activar comandos slash inmediatamente.

> ⚠️ **IMPORTANTE EN EL DEVELOPER PORTAL**:
> En la pestaña **Bot**, activa el permiso **Message Content Intent** en la sección *Privileged Gateway Intents*. Sin esto, Discord no permitirá al bot leer los mensajes para analizarlos.

---

## 2. Configurar Variables de Entorno

Copia el archivo de plantilla a `.env`:
```bash
cp .env.example .env
```
Edita `.env` con tus claves:
```env
DISCORD_TOKEN=tu_token_aqui
DISCORD_CLIENT_ID=tu_client_id_aqui
DISCORD_GUILD_ID=tu_id_de_servidor_opcional
```

---

## 3. Instalación de Dependencias

```bash
npm install
```

---

## 4. Métodos de Ejecución

### Opción A: Despliegue Completo (Bot + Panel Web en Puerto 3000)
Compila el frontend y el servidor:
```bash
npm run build
npm start
```
Esto arrancará el bot de Discord y el panel web de control y logs en `http://localhost:3000`.

### Opción B: Ejecución Solo Bot (Modo Worker / Background)
Si solo quieres que el bot esté conectado a Discord sin abrir servidor web:
```bash
npm run bot
```

### Opción C: Registrar Comandos Slash
Para sincronizar el comando `/scamlock` con Discord:
```bash
npm run deploy-commands
```

---

## 5. Hosting 24/7 en VPS (Ubuntu / Debian con PM2)

1. Instalar PM2 globalmente:
```bash
npm install -g pm2
```
2. Compilar el proyecto:
```bash
npm run build
```
3. Iniciar el servicio con PM2:
```bash
pm2 start dist/server.cjs --name "scamlock-bot"
```
4. Configurar reinicio automático tras reinicio del servidor:
```bash
pm2 save
pm2 startup
```

---

## 6. Hosting con Docker

Si utilizas Docker y Docker Compose:
```bash
# 1. Asegúrate de tener tu archivo .env configurado
# 2. Levantar contenedor en segundo plano:
docker compose up -d --build
```
Para ver logs del bot:
```bash
docker compose logs -f
```

---

## 7. Hosting en la Nube (Railway, Render, Fly.io)

1. Sube el código a un repositorio privado de GitHub o conecta la carpeta del proyecto.
2. En las variables de entorno del servicio en la nube, añade:
   - `DISCORD_TOKEN`
   - `DISCORD_CLIENT_ID`
3. **Build Command**: `npm install && npm run build`
4. **Start Command**: `npm start`
5. El bot se conectará automáticamente a la pasarela de Discord en cuanto inicie el contenedor.
