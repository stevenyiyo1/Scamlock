import os
import shutil
import zipfile

exclude_dirs = {'node_modules', '.git', 'dist', '.cache', '__pycache__', '.temp', '.vscode'}
exclude_files = {'scam-lock-project.zip', 'scamlock-bot.zip', '.DS_Store'}

output_zip = os.path.join('public', 'scamlock-bot.zip')
os.makedirs('public', exist_ok=True)

with zipfile.ZipFile(output_zip, 'w', zipfile.ZIP_DEFLATED) as zf:
    for root, dirs, files in os.walk('.'):
        dirs[:] = [d for d in dirs if d not in exclude_dirs and not d.startswith('.git')]
        for file in files:
            if file in exclude_files or file.endswith('.zip'):
                continue
            full_path = os.path.join(root, file)
            rel_path = os.path.relpath(full_path, '.')
            if rel_path.startswith('.' + os.sep):
                rel_path = rel_path[2:]
            zf.write(full_path, rel_path)

# Also copy to scam-lock-project.zip for convenience
shutil.copyfile(output_zip, os.path.join('public', 'scam-lock-project.zip'))

print(f"Zip created successfully: {os.path.getsize(output_zip)} bytes")
