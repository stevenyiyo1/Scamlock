// Scam Lock - Deploy Slash Commands Runner
import { deploySlashCommands } from './src/bot/deploy-commands.ts';
import dotenv from 'dotenv';
dotenv.config();

console.log('[Scam Lock] 🚀 Iniciando registro de comandos Slash en Discord...');
deploySlashCommands().then((res) => {
  console.log(res.message);
  process.exit(res.success ? 0 : 1);
}).catch((err) => {
  console.error('[Scam Lock] ❌ Error:', err);
  process.exit(1);
});
